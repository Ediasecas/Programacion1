package valddec;

public enum TipoConsulta {
    General, Alergias, Urgencia, Otorrino, Traumatologo
}

