
public enum Enumerado 
{
	INFORMATICA,GESTION,MARKETING
}
