/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author daw1
 */
public class Cuenta 
{

	private String cod;
	private String nombreCuenta;
	private String numCuenta;
	private Double saldo;
	
	public Cuenta(String cod, String nombreCuenta, String numCuenta, Double saldo)
	{
		super();
		this.cod = cod;
		this.nombreCuenta = nombreCuenta;
		this.numCuenta = numCuenta;
		this.saldo = saldo;
	}

	
	public String getCod() 
	{
		return cod;
	}

	public void setCod(String cod) 
	{
		this.cod = cod;
	}

	
	public String getNombreCuenta() 
	{
		return nombreCuenta;
	}


	public void setNombreCuenta(String nombreCuenta) 
	{
		this.nombreCuenta = nombreCuenta;
	}

	
	public String getNumCuenta() 
	{
		return numCuenta;
	}

	public void setNumCuenta(String numCuenta) 
	{
		this.numCuenta = numCuenta;
	}
	

	public Double getSaldo() 
	{
		return saldo;
	}

	public void setSaldo(Double saldo) 
	{
		this.saldo = saldo;
	}


	
	@Override
	public String toString() 
	{
		return "Cuenta [Codigo identificativo:" + cod + ", Nombre del titular de la cuenta:" + nombreCuenta + ", Numero de cuenta:" + numCuenta + ", Saldo:" + saldo
				+ "]";
	}

}


 


