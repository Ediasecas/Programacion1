
public enum TipoMovimiento
{
	INGRESO, RETIRADA
}
