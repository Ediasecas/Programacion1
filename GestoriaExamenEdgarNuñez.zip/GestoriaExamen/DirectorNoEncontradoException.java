
public class DirectorNoEncontradoException extends Exception
{
	 public DirectorNoEncontradoException() 
	 {
	     super("No hay director registrado en la empresa.");
	 }
}
